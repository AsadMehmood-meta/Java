package main;

import manytomany.Course;
import manytomany.Student;
import onetomany.Branch;
import onetomany.SecurityLog;

public class Main {

    public static void manyToMany(){
        Student s1 = new Student("Asad Mehmood" , "asad@gmail.com");
        Student s2 = new Student("Usama Khan" , "usama@gmail.com");
        Student s3 = new Student("Ali Shahid", "ali@gmailcom");

        Course c1 = new Course("Java","CS-101");
        Course c2 = new Course("Oops","CS-103");

        s1.getEnroll(c1);
        s1.getEnroll(c2);
        s2.getEnroll(c2);
        s3.getEnroll(c1);

        c1.getCourseDetail();

        s1.getStudentsDetail();
    }

    public static void oneToMany(){
        Branch b1 = new Branch("Gulshan" , "Karachi" , "Asad");
        Branch b2 = new Branch("Johar" , "Karachi" , "Usama");
        Branch b3 = new Branch("DHA atm" , "Karachi" , "Ahmed");

        SecurityLog l1 = new SecurityLog("cctv issue, connection lost.","High","Critical");
        SecurityLog l2 = new SecurityLog("door unlocked.","High","Critical");
        SecurityLog l3 = new SecurityLog("cctv issue, connection lost.","High","Critical");
        SecurityLog l4 = new SecurityLog("door unlocked.","High","Critical");

        b1.addSecurityLog(l1);
        b1.addSecurityLog(l2);
        b2.addSecurityLog(l1);
        b3.addSecurityLog(l3);
        b3.addSecurityLog(l4);


        b3.getBranchDetails();


    }


    public static void main(String[] args) {
        System.out.println("Hello from main");

        //many-to-many relation, student and courses
        manyToMany();

        //one-to-many relation,  bank branch and security logs
        oneToMany();
        

    }
}
