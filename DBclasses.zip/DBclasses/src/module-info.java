module Practice {
    requires DBClasses;
}