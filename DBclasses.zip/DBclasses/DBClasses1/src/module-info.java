module DBClasses {
    exports manytomany;
    exports onetomany;
}