package onetomany;

import java.time.LocalDateTime;

public class SecurityLog {
    private int logID;
    private static int logIDCount = 201;
    private LocalDateTime timestamp;
    private String description;
    private String severity;
    private String status;
    private Branch branch;

    public void setBranch(Branch branch) {
        this.branch = branch;
    }

    public SecurityLog(String description, String severity, String status) {
        this.logID = logIDCount++;
        this.timestamp = LocalDateTime.now();
        this.description = description;
        this.severity = severity;
        this.status = status;
    }

    public void getLogDetail(){
        System.out.println("Log ID\t:\t"+logID+"\t|\tBranch ID\t:\t"+branch.getBranchID());
        System.out.println("Description : "+description);
        System.out.println("Severity\t:\t"+severity+"\t|\tStatus\t:\t"+status);
    }
}
