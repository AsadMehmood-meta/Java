package onetomany;

import java.util.ArrayList;
import java.util.List;

public class Branch {
    private int branchID;
    private static int idCount = 101;
    private String branchName;
    private String location;
    private String branchManager;
    private List<SecurityLog> logs = new ArrayList<>();

    public Branch(String branchName, String location, String branchManager) {
        this.branchID = idCount++;
        this.branchName = branchName;
        this.location = location;
        this.branchManager = branchManager;
    }

    public int getBranchID() {
        return branchID;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getBranchManager() {
        return branchManager;
    }

    public void setBranchManager(String branchManager) {
        this.branchManager = branchManager;
    }

    public void addSecurityLog(SecurityLog log){
        logs.add(log);
        log.setBranch(this);
    }

    public void getBranchDetails(){
        System.out.println("Branch ID: "+branchID+".\t|\tBranch Name: "+branchName+".");
        System.out.println("Location: "+location+".\t|\tBranch Manager: "+branchManager+".");
        System.out.println("\nDetails of security logs:");
        for(SecurityLog s : logs){
            s.getLogDetail();
        }
    }

}
