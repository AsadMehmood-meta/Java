package manytomany;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseName;
    private String courseCode;
    private List<Student> students = new ArrayList<>();

    public Course(String courseName, String courseCode) {
        this.courseName = courseName;
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public void addStudent(Student student) {
        this.students.add(student);
    }

    public void getCourseDetail(){
        System.out.println("Course details:");
        System.out.println("Course name : "+courseName+"\nCourse code : "+courseCode);
        System.out.println("Following students are enrolled in "+courseName+" course:");
        for(Student s : students){
            System.out.println("Name : "+s.getStudentName());
        }
    }
}
