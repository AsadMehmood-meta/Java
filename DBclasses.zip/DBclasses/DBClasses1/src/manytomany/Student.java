package manytomany;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String studentName;
    private String studentEmail;
    private List<Course> courses = new ArrayList<>();

    public Student(String studentName, String studentEmail) {
        this.studentName = studentName;
        this.studentEmail = studentEmail;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public void getEnroll(Course course) {
        if(!this.courses.contains(course)){
            this.courses.add(course);
            course.addStudent(this);
        }else{
            System.out.println(studentName+" already enrolled in this course");
        }
    }

    public void getStudentsDetail(){
        System.out.println("Students Detail:");
        System.out.println("Name : "+studentName+"\nEmail : "+studentEmail);
        System.out.println(studentName+" enrolled in following courses:");
        for(Course c : courses){
            System.out.println("Course : "+c.getCourseName()+"\t|\tCode : "+c.getCourseCode());
        }
    }
}
