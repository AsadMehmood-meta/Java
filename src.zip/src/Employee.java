public class Employee  {
    private int id;
    private String name;
    private int age;
    private String email;
    private String department;
    private String password;
    private static int uniqueID = 1;

    Employee(String name , int age , String email , String department , String password) throws InvalidAgeException, InvalidNameException, InvalidEmailException {

        id = uniqueID++;
            if(name == null || name.isEmpty()){
                throw new InvalidNameException("Name cannot be null or empty.");
            }
            this.name = name;

            if(age < 18){
                throw new InvalidAgeException("Age must be greater than or equals to 18.");
            }
            this.age = age;


            if(!email.contains("@")){
                throw new InvalidEmailException("Invalid email format.");
            }
            this.email = email;

        this.department = department;

        this.password = password;

    }

    void encryptPassword(String pass){
        String encryptPassword;
        for(int i=0 ; i<pass.length() ; i++){
            int x = pass.charAt(i);
            if((x >= 65) && (x<=91)){
                x-=65;
            }else if ((x >= 97) && (x<=123)){
                x-=97;
            }
            char ch = (char)(x);

        }
    }

    public String toString(){
        return "{\n\t\"id\" : " + id + ",\n\t\"name\" : " + "\"" + name + "\",\n\t\"age\" : " + age + ",\n\t\"email\" : \"" + email + "\",\n\t\"department\" : " + "\"" +department + ",\n\t\"password\" : \"" + password  + "\"\n}\n";
    }



}
