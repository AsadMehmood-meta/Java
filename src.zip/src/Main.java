
public class Main{

    public static void main(String[] args)  {

//        Employee(name ,age ,email ,department ,password)

        try{
            Employee e1 = new Employee("Asad" , 28 , "asad@gmail.com" , "HR" , "asd123" );

            Employee e2 = new Employee("Asad" , 28 , "asad@gmail.com" , "HR" , "asd123" );

            System.out.println(e1.toString());
            System.out.println(e2.toString());
        }
        catch(InvalidNameException e){
            System.out.println("Custom Invalid name exception : " + e.getMessage());
        }
        catch(InvalidAgeException e){
            System.out.println("Custom Invalid age exception : " + e.getMessage());
        }
        catch(InvalidEmailException e){
            System.out.println("Custom Invalid email exception : " + e.getMessage());
        }
        catch(Exception e){
            System.out.println("General exception : " + e.getMessage());
        }

        //Create objects with exceptions
        try{
            Employee e3 = new Employee("" , 28 , "asad@gmail.com" , "HR" , "asd123" );

            Employee e4 = new Employee("Asad" , 15 , "asad@gmail.com" , "HR" , "asd123" );

            Employee e5 = new Employee("Asad" , 15 , "asadgmail.com" , "HR" , "asd123" );

            System.out.println(e3.toString());
            System.out.println(e4.toString());
            System.out.println(e5.toString());
        }
        catch(InvalidNameException e){
            System.out.println("Custom Invalid name exception : " + e.getMessage());
        }
        catch(InvalidAgeException e){
            System.out.println("Custom Invalid age exception : " + e.getMessage());
        }
        catch(InvalidEmailException e){
            System.out.println("Custom Invalid email exception : " + e.getMessage());
        }
        catch(Exception e){
            System.out.println("General exception : " + e.getMessage());
        }
        finally {
            System.out.println("Program end.");
        }

    }
}